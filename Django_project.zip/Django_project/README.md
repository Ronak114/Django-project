# Project_Management_tool_djangol
Django project for project management tool
